<?php
//session_start();
if (condition) {
	# code...
}
